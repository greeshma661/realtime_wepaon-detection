yolov3_training_2000.weights: https://drive.google.com/open?id=1YZAuYjxgp1cQImV-iNhJ6SGkBSxqR71M&usp=drive_copy
